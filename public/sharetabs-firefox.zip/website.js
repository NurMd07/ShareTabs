export default {
  name: 'https://tabs.creative9.tech'
};
