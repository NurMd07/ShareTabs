const button = document.querySelector('.btn1');
const checkbox = document.querySelector('#flexSwitchCheckDefault');
const usernameInput = document.querySelector('#username');
const passwordInput = document.querySelector('#password');
const statusMessage = document.querySelector('.status');

const setStatus = (message, isError = false) => {
  statusMessage.textContent = message;
  statusMessage.classList.toggle('text-danger', isError);
  statusMessage.classList.toggle('text-success', !isError && Boolean(message));
};

const sendRuntimeMessage = (action) => new Promise((resolve, reject) => {
  chrome.runtime.sendMessage({ action }, (response) => {
    if (chrome.runtime.lastError) {
      reject(new Error(chrome.runtime.lastError.message));
      return;
    }

    resolve(response);
  });
});

const getStoredUrls = () => new Promise((resolve, reject) => {
  chrome.storage.local.get(['urls'], (result) => {
    if (chrome.runtime.lastError) {
      reject(new Error(chrome.runtime.lastError.message));
      return;
    }

    resolve(result.urls);
  });
});

const encodeBasicCredentials = (username, password) => {
  const bytes = new TextEncoder().encode(`${username}:${password}`);
  const binary = Array.from(bytes, (byte) => String.fromCharCode(byte)).join('');

  return `Basic ${btoa(binary)}`;
};

const getUrls = async (currentTabOnly) => {
  const response = await sendRuntimeMessage(currentTabOnly ? 'currentTab' : 'buttonClicked');
  const storedUrls = await getStoredUrls();
  const urls = (Array.isArray(storedUrls) ? storedUrls : [storedUrls])
    .filter((url) => typeof url === 'string')
    .map((url) => url.trim())
    .filter((url) => url && !/^(chrome|edge):/i.test(url));

  return { urls, reloadTab: response && response.tabs };
};

const sendTabs = async () => {
  const username = usernameInput.value.trim();
  const password = passwordInput.value;

  if (!username || !password) {
    setStatus('Enter your username and password.', true);
    return;
  }

  button.disabled = true;
  button.textContent = 'Sending...';
  setStatus('');

  try {
    const [website, tabData] = await Promise.all([
      sendRuntimeMessage('website_name'),
      getUrls(checkbox.checked)
    ]);

    if (!tabData.urls.length) {
      throw new Error('No eligible tabs to send.');
    }

    const response = await fetch(`${website}/urls`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: encodeBasicCredentials(username, password)
      },
      body: JSON.stringify({ urls: tabData.urls })
    });

    const result = await response.json().catch(() => null);
    if (response.status === 401) {
      throw new Error('Username or password is incorrect.');
    }
    if (response.status === 503) {
      throw new Error('Extension sign-in is unavailable. Contact the site administrator.');
    }
    if (!response.ok || !(result === 'success' || result?.success === true)) {
      throw new Error(result?.message || 'Could not send tabs. Please try again.');
    }

    button.textContent = 'Sent';
    setStatus(`${result.saved ?? tabData.urls.length} tab(s) accepted.`);

    if (Number.isInteger(tabData.reloadTab)) {
      window.setTimeout(() => chrome.tabs.reload(tabData.reloadTab), 300);
    }
  } catch (error) {
    button.textContent = checkbox.checked ? 'Send Current Tab' : 'Send All Tabs';
    setStatus(error.message || 'Could not send tabs. Please try again.', true);
  } finally {
    button.disabled = false;
  }
};

checkbox.addEventListener('change', () => {
  button.textContent = checkbox.checked ? 'Send Current Tab' : 'Send All Tabs';
});

button.addEventListener('click', sendTabs);
